package com.msr.skillvotask.model;

/**
 * Created by Sandeep Maram on 9/29/2016.
 */

public class GridItem {

    private String imageUrl;
    private int degrees = 0;

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getDegrees() {
        return degrees;
    }

    public void setDegrees(int degrees) {
        this.degrees = degrees;
    }

}
